    Install
------------------
1) Copy files wpkg.js and config.xml to %WPIPATH%\Tools\wpkg
2) Copy file updateWPI.js to %WPIPATH%
3) Open file updateWPI.js and replace 'http://wpkg.fabricam.com' to correct WPKG URL in string:
    var sDownloadURL = "http://wpkg.fabricam.com/wpi/config.js"
